const dataInfo = `
[
    {
        "img":"./img/s2k1.png",
        "h3":"ELLERY X M'O CAPSULE",
        "p":"Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "pr":"$52.00",
        "color": "Black",
        "size": "XL",
        "quantity": 1,
        "n":1
    },
    {
        "img":"./img/s2k2.png",
        "h3":"ELLERY X M'O CAPSULE",
        "p":"Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "pr":"$52.00",
        "color": "Black",
        "size": "XL",
        "quantity": 1,
        "n":2
    },
    {
        "img":"./img/s2k3.png",
        "h3":"ELLERY X M'O CAPSULE",
        "p":"Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "pr":"$52.00",
        "color": "Black",
        "size": "XL",
        "quantity": 1,
        "n":3
    },
    {
        "img":"./img/s2k4.png",
        "h3":"ELLERY X M'O CAPSULE",
        "p":"Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "pr":"$52.00",
        "color": "Black",
        "size": "XL",
        "quantity": 1,
        "n":4
    },
    {
        "img":"./img/s2k5.png",
        "h3":"ELLERY X M'O CAPSULE",
        "p":"Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "pr":"$52.00",
        "color": "Black",
        "size": "XL",
        "quantity": 1,
        "n":5
    },
    {
        "img":"./img/s2k6.png",
        "h3":"ELLERY X M'O CAPSULE",
        "p":"Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "pr":"$52.00",
        "color": "Black",
        "size": "XL",
        "quantity": 1,
        "n":6
    }
]
`;
